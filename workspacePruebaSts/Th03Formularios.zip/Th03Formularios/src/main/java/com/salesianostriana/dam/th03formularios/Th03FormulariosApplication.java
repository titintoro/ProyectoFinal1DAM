package com.salesianostriana.dam.th03formularios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Th03FormulariosApplication {

	public static void main(String[] args) {
		SpringApplication.run(Th03FormulariosApplication.class, args);
	}
}
