/**
 * 
 */
/**
 * @author lmlopez
 *
 */
package com.salesianostriana.dam.modelo;